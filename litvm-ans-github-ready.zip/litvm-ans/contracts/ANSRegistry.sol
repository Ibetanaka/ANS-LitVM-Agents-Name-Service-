// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title ANSRegistry
/// @notice A lightweight Agent Name Service registry for on-chain AI agents.
/// Names resolve to an agent address, owner, metadata URI, and active status.
contract ANSRegistry {
    struct AgentRecord {
        address agent;
        address owner;
        string metadataURI;
        uint64 registeredAt;
        bool active;
    }

    address public admin;
    uint256 public registrationFee;
    uint256 public totalRegistered;

    mapping(bytes32 => AgentRecord) private records;
    mapping(address => bytes32) private reverseName;
    mapping(bytes32 => string) private nameOf;
    bytes32[] private allNameHashes;

    event NameRegistered(
        string indexed nameIndexed,
        string name,
        address indexed agent,
        address indexed owner
    );
    event NameUpdated(string name, address indexed agent, string metadataURI);
    event NameTransferred(
        string name,
        address indexed previousOwner,
        address indexed newOwner
    );
    event NameDeactivated(string name);
    event FeeUpdated(uint256 newFee);

    modifier onlyAdmin() {
        require(msg.sender == admin, "ANS: caller is not admin");
        _;
    }

    modifier onlyNameOwner(string memory name) {
        bytes32 h = _hash(name);
        require(records[h].owner == msg.sender, "ANS: caller is not name owner");
        _;
    }

    constructor(uint256 _registrationFee) {
        admin = msg.sender;
        registrationFee = _registrationFee;
    }

    /// @notice Register a unique name for an agent.
    function register(
        string calldata name,
        address agent,
        string calldata metadataURI
    ) external payable {
        require(
            bytes(name).length > 0 && bytes(name).length <= 64,
            "ANS: invalid name length"
        );
        require(agent != address(0), "ANS: agent is zero address");
        require(msg.value >= registrationFee, "ANS: insufficient fee");

        bytes32 h = _hash(name);
        require(records[h].agent == address(0), "ANS: name already taken");
        require(reverseName[agent] == bytes32(0), "ANS: agent already has a name");

        records[h] = AgentRecord({
            agent: agent,
            owner: msg.sender,
            metadataURI: metadataURI,
            registeredAt: uint64(block.timestamp),
            active: true
        });

        reverseName[agent] = h;
        nameOf[h] = name;
        allNameHashes.push(h);
        totalRegistered += 1;

        emit NameRegistered(name, name, agent, msg.sender);
    }

    /// @notice Update the metadata URI for a name.
    function updateMetadata(
        string calldata name,
        string calldata metadataURI
    ) external onlyNameOwner(name) {
        bytes32 h = _hash(name);
        records[h].metadataURI = metadataURI;
        emit NameUpdated(name, records[h].agent, metadataURI);
    }

    /// @notice Update the agent address associated with a name.
    function updateAgentAddress(
        string calldata name,
        address newAgent
    ) external onlyNameOwner(name) {
        require(newAgent != address(0), "ANS: agent is zero address");

        bytes32 h = _hash(name);
        require(
            reverseName[newAgent] == bytes32(0) || reverseName[newAgent] == h,
            "ANS: new agent already has a name"
        );

        delete reverseName[records[h].agent];
        records[h].agent = newAgent;
        reverseName[newAgent] = h;

        emit NameUpdated(name, newAgent, records[h].metadataURI);
    }

    /// @notice Transfer ownership of a registered name.
    function transferName(
        string calldata name,
        address newOwner
    ) external onlyNameOwner(name) {
        require(newOwner != address(0), "ANS: new owner is zero address");

        bytes32 h = _hash(name);
        address previous = records[h].owner;
        records[h].owner = newOwner;

        emit NameTransferred(name, previous, newOwner);
    }

    /// @notice Deactivate a name without deleting its history.
    function deactivate(string calldata name) external onlyNameOwner(name) {
        bytes32 h = _hash(name);
        records[h].active = false;
        emit NameDeactivated(name);
    }

    /// @notice Resolve a name to its complete agent record.
    function resolve(string calldata name)
        external
        view
        returns (
            address agent,
            address owner,
            string memory metadataURI,
            uint64 registeredAt,
            bool active
        )
    {
        AgentRecord memory r = records[_hash(name)];
        require(r.agent != address(0), "ANS: name not found");

        return (
            r.agent,
            r.owner,
            r.metadataURI,
            r.registeredAt,
            r.active
        );
    }

    /// @notice Reverse lookup from agent address to its registered name.
    function nameOfAgent(address agent) external view returns (string memory) {
        bytes32 h = reverseName[agent];
        require(bytes(nameOf[h]).length > 0, "ANS: agent has no name");
        return nameOf[h];
    }

    function isRegistered(string calldata name) external view returns (bool) {
        return records[_hash(name)].agent != address(0);
    }

    function totalNames() external view returns (uint256) {
        return allNameHashes.length;
    }

    function nameAt(uint256 index) external view returns (string memory) {
        require(index < allNameHashes.length, "ANS: index out of range");
        return nameOf[allNameHashes[index]];
    }

    function setRegistrationFee(uint256 newFee) external onlyAdmin {
        registrationFee = newFee;
        emit FeeUpdated(newFee);
    }

    function setAdmin(address newAdmin) external onlyAdmin {
        require(newAdmin != address(0), "ANS: zero address");
        admin = newAdmin;
    }

    function withdraw(address payable to) external onlyAdmin {
        require(to != address(0), "ANS: zero address");

        (bool success, ) = to.call{value: address(this).balance}("");
        require(success, "ANS: withdrawal failed");
    }

    function _hash(string memory name) internal pure returns (bytes32) {
        return keccak256(abi.encodePacked(name));
    }
}
