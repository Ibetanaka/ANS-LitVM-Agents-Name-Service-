// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IANSRegistry {
    function isRegistered(string calldata name) external view returns (bool);

    function resolve(string calldata name)
        external
        view
        returns (
            address agent,
            address owner,
            string memory metadataURI,
            uint64 registeredAt,
            bool active
        );
}

/// @title AgentScorer
/// @notice Records scanner-reported agent performance and calculates weighted scores.
/// Scores cover speed, decision quality, and execution from 0 to 100.
contract AgentScorer {
    struct ScanResult {
        uint64 timestamp;
        uint8 speed;
        uint8 decision;
        uint8 execution;
        bool success;
        string taskId;
        address scanner;
    }

    struct AgentStats {
        uint64 scanCount;
        uint64 successCount;
        uint256 sumSpeed;
        uint256 sumDecision;
        uint256 sumExecution;
        bool exists;
    }

    address public admin;
    IANSRegistry public registry;

    uint16 public weightSpeed = 3334;
    uint16 public weightDecision = 3333;
    uint16 public weightExecution = 3333;

    mapping(address => bool) public isScanner;
    mapping(address => AgentStats) public statsOf;
    mapping(address => ScanResult[]) private historyOf;
    address[] private scannedAgents;
    mapping(address => bool) private seenAgent;

    event ScannerAdded(address indexed scanner);
    event ScannerRemoved(address indexed scanner);
    event ScanSubmitted(
        address indexed agent,
        address indexed scanner,
        string taskId,
        uint8 speed,
        uint8 decision,
        uint8 execution,
        bool success
    );
    event WeightsUpdated(
        uint16 speed,
        uint16 decision,
        uint16 execution
    );

    modifier onlyAdmin() {
        require(msg.sender == admin, "Scorer: caller is not admin");
        _;
    }

    modifier onlyScanner() {
        require(
            isScanner[msg.sender] || msg.sender == admin,
            "Scorer: caller is not an authorized scanner"
        );
        _;
    }

    constructor(address _registry) {
        admin = msg.sender;
        registry = IANSRegistry(_registry);
        isScanner[msg.sender] = true;
        emit ScannerAdded(msg.sender);
    }

    function addScanner(address scanner) external onlyAdmin {
        require(scanner != address(0), "Scorer: zero address");
        isScanner[scanner] = true;
        emit ScannerAdded(scanner);
    }

    function removeScanner(address scanner) external onlyAdmin {
        isScanner[scanner] = false;
        emit ScannerRemoved(scanner);
    }

    function setWeights(
        uint16 _speed,
        uint16 _decision,
        uint16 _execution
    ) external onlyAdmin {
        require(
            uint256(_speed) + uint256(_decision) + uint256(_execution) == 10000,
            "Scorer: weights must sum to 10000"
        );

        weightSpeed = _speed;
        weightDecision = _decision;
        weightExecution = _execution;

        emit WeightsUpdated(_speed, _decision, _execution);
    }

    /// @notice Submit one scanner result for an agent.
    function submitScan(
        address agent,
        uint8 speed,
        uint8 decision,
        uint8 execution,
        bool success,
        string calldata taskId
    ) external onlyScanner {
        _submitScan(
            agent,
            speed,
            decision,
            execution,
            success,
            taskId,
            msg.sender
        );
    }

    /// @notice Submit multiple scanner results in one transaction.
    function submitScanBatch(
        address[] calldata agents,
        uint8[] calldata speeds,
        uint8[] calldata decisions,
        uint8[] calldata executions,
        bool[] calldata successes,
        string[] calldata taskIds
    ) external onlyScanner {
        uint256 n = agents.length;

        require(
            n == speeds.length &&
            n == decisions.length &&
            n == executions.length &&
            n == successes.length &&
            n == taskIds.length,
            "Scorer: array length mismatch"
        );

        for (uint256 i = 0; i < n; i++) {
            _submitScan(
                agents[i],
                speeds[i],
                decisions[i],
                executions[i],
                successes[i],
                taskIds[i],
                msg.sender
            );
        }
    }

    function _submitScan(
        address agent,
        uint8 speed,
        uint8 decision,
        uint8 execution,
        bool success,
        string calldata taskId,
        address scanner
    ) internal {
        require(agent != address(0), "Scorer: zero address");
        require(
            speed <= 100 &&
            decision <= 100 &&
            execution <= 100,
            "Scorer: scores must be 0-100"
        );

        AgentStats storage s = statsOf[agent];

        if (!s.exists) {
            s.exists = true;
        }

        if (!seenAgent[agent]) {
            seenAgent[agent] = true;
            scannedAgents.push(agent);
        }

        s.scanCount += 1;

        if (success) {
            s.successCount += 1;
        }

        s.sumSpeed += speed;
        s.sumDecision += decision;
        s.sumExecution += execution;

        historyOf[agent].push(
            ScanResult({
                timestamp: uint64(block.timestamp),
                speed: speed,
                decision: decision,
                execution: execution,
                success: success,
                taskId: taskId,
                scanner: scanner
            })
        );

        emit ScanSubmitted(
            agent,
            scanner,
            taskId,
            speed,
            decision,
            execution,
            success
        );
    }

    function getAgentScore(address agent)
        public
        view
        returns (
            uint256 avgSpeed,
            uint256 avgDecision,
            uint256 avgExecution,
            uint256 composite,
            uint64 scanCount,
            uint64 successCount
        )
    {
        AgentStats memory s = statsOf[agent];

        if (s.scanCount == 0) {
            return (0, 0, 0, 0, 0, 0);
        }

        avgSpeed = s.sumSpeed / s.scanCount;
        avgDecision = s.sumDecision / s.scanCount;
        avgExecution = s.sumExecution / s.scanCount;

        composite =
            (avgSpeed * weightSpeed +
                avgDecision * weightDecision +
                avgExecution * weightExecution) /
            10000;

        scanCount = s.scanCount;
        successCount = s.successCount;
    }

    function getHistoryLength(address agent) external view returns (uint256) {
        return historyOf[agent].length;
    }

    function getHistoryAt(address agent, uint256 index)
        external
        view
        returns (ScanResult memory)
    {
        require(
            index < historyOf[agent].length,
            "Scorer: index out of range"
        );
        return historyOf[agent][index];
    }

    function totalScannedAgents() external view returns (uint256) {
        return scannedAgents.length;
    }

    function scannedAgentAt(uint256 index) external view returns (address) {
        require(index < scannedAgents.length, "Scorer: index out of range");
        return scannedAgents[index];
    }

    function getLeaderboardPage(uint256 offset, uint256 limit)
        external
        view
        returns (
            address[] memory agents,
            uint256[] memory composites,
            uint64[] memory scanCounts
        )
    {
        uint256 total = scannedAgents.length;

        if (offset >= total || limit == 0) {
            return (
                new address[](0),
                new uint256[](0),
                new uint64[](0)
            );
        }

        uint256 end = offset + limit;

        if (end < offset || end > total) {
            end = total;
        }

        uint256 len = end - offset;

        agents = new address[](len);
        composites = new uint256[](len);
        scanCounts = new uint64[](len);

        for (uint256 i = 0; i < len; i++) {
            address agent = scannedAgents[offset + i];

            (
                ,
                ,
                ,
                uint256 composite,
                uint64 scanCount,

            ) = getAgentScore(agent);

            agents[i] = agent;
            composites[i] = composite;
            scanCounts[i] = scanCount;
        }
    }

    function setRegistry(address _registry) external onlyAdmin {
        registry = IANSRegistry(_registry);
    }

    function setAdmin(address newAdmin) external onlyAdmin {
        require(newAdmin != address(0), "Scorer: zero address");
        admin = newAdmin;
    }
}
