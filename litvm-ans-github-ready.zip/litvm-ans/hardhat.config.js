require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

/**
 * LitVM Testnet (LiteForge)
 * Chain ID: 4441
 * Native gas token: zkLTC
 */
module.exports = {
  solidity: {
    version: "0.8.24",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200
      }
    }
  },
  networks: {
    litvmTestnet: {
      url: process.env.LITVM_RPC_URL || "https://liteforge.rpc.caldera.xyz/infra-partner-http",
      chainId: 4441,
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : []
    },
    hardhat: {}
  },
  etherscan: {
    apiKey: {
      litvmTestnet: process.env.LITVM_EXPLORER_API_KEY || "no-api-key-needed"
    },
    customChains: [
      {
        network: "litvmTestnet",
        chainId: 4441,
        urls: {
          apiURL: "https://liteforge.caldera.xyz/api",
          browserURL: "https://liteforge.caldera.xyz"
        }
      }
    ]
  }
};
