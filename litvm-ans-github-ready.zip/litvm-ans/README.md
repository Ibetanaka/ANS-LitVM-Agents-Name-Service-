# ANS + Agent Scanner for LitVM

Agent Name Service (ANS) and on-chain agent scoring infrastructure for the **LitVM Testnet (LiteForge)**.

The project provides two core smart contracts:

- **ANSRegistry** — maps human-readable agent names to AI agent addresses and metadata.
- **AgentScorer** — records scanner-based performance scores for speed, decision quality, and execution.

## Network

| Property | Value |
|---|---|
| Network | LitVM Testnet |
| Chain ID | `4441` |
| Native Gas Token | `zkLTC` |
| RPC | `https://liteforge.rpc.caldera.xyz/infra-partner-http` |
| Explorer | `https://liteforge.caldera.xyz` |

## Repository Structure

```text
litvm-ans/
├── contracts/
│   ├── ANSRegistry.sol
│   └── AgentScorer.sol
├── scripts/
│   └── deploy.js
├── frontend/
│   └── index.html
├── .env.example
├── .gitignore
├── hardhat.config.js
├── package.json
└── README.md
```

## What It Does

### ANSRegistry

`ANSRegistry.sol` provides:

- `register(name, agentAddress, metadataURI)` — registers a unique name for an agent.
- `resolve(name)` — resolves a name to its agent address, owner, metadata, registration time, and active status.
- `nameOfAgent(address)` — reverse lookup from an agent address to its registered name.
- `updateMetadata(name, metadataURI)` — updates agent metadata.
- `updateAgentAddress(name, newAgent)` — updates the address associated with a name.
- `transferName(name, newOwner)` — transfers name ownership.
- `deactivate(name)` — marks a name as inactive.
- Registration fee management and admin-controlled withdrawal.

### AgentScorer

`AgentScorer.sol` provides:

- Authorized scanners that submit task results on-chain.
- Three performance dimensions, each scored from `0` to `100`:
  - **Speed** — how quickly the agent completes a task relative to the target.
  - **Decision** — the quality, accuracy, relevance, and efficiency of the agent's decisions.
  - **Execution** — whether the intended result was successfully achieved.
- A weighted composite score calculated on-chain.
- Per-agent scan and success counters.
- Complete scan history for auditability.
- Batch submission for lower transaction overhead.
- A paginated leaderboard that can be read directly by the frontend.

The default weights are approximately one-third each:

```text
Speed      33.34%
Decision   33.33%
Execution  33.33%
```

The admin can update the weights as long as they total `10000` basis points.

## Scanner Model

A scanner can be an off-chain service that monitors agent execution and submits the resulting scores to `AgentScorer`.

For example, a scanner may evaluate:

1. Response or completion time → **speed**
2. Decision path, strategy, and prioritization → **decision**
3. Final task outcome → **execution**
4. Overall task result → **success**

Only authorized scanner addresses can submit results.

For production use, consider decentralized scoring, multiple independent scanners, staking/slashing, rate limiting, and/or a multisig admin.

## Requirements

- Node.js
- npm
- A wallet with LitVM testnet `zkLTC`
- A deployer private key stored locally in `.env`

## Installation

```bash
npm install
```

Create your local environment file:

```bash
cp .env.example .env
```

Then add your deployer private key:

```env
PRIVATE_KEY=0xYOUR_PRIVATE_KEY
LITVM_RPC_URL=https://liteforge.rpc.caldera.xyz/infra-partner-http
LITVM_EXPLORER_API_KEY=
```

**Never commit `.env` or a private key to GitHub.**

## Compile

```bash
npm run compile
```

## Test

```bash
npm test
```

No test suite is included in this initial repository snapshot. Add contract tests before production deployment.

## Deploy to LitVM

```bash
npm run deploy:litvm
```

The deployment script:

1. Deploys `ANSRegistry`.
2. Deploys `AgentScorer` linked to the registry.
3. Authorizes `CREATOR_ADDRESS` as a scanner.
4. Removes the deployer from the scanner role.
5. Transfers admin control of both contracts to `CREATOR_ADDRESS`.
6. Prints the deployed contract addresses.

Before deployment, verify the `CREATOR_ADDRESS` in `scripts/deploy.js`.

After deployment, copy the printed addresses into:

```text
frontend/index.html
```

inside:

```js
const CONFIG = {
  registryAddress: "0x...",
  scorerAddress: "0x...",
};
```

## Frontend

The frontend is a single static HTML file and does not require a build system.

Open:

```text
frontend/index.html
```

or serve it locally with:

```bash
npx serve frontend
```

The dashboard supports:

- Wallet connection
- LitVM network switching
- Agent name registration
- Name resolution
- Scan submission for authorized scanners
- On-chain leaderboard
- Demo mode before contract addresses are configured

## Security Notes

This repository targets a **testnet** deployment.

Before using it on mainnet:

- Perform a professional smart contract audit.
- Add a comprehensive automated test suite.
- Use a multisig for administrative control.
- Consider decentralized scanner/oracle architecture.
- Add rate limiting or anti-spam mechanisms.
- Review name ownership and agent-address collision rules.
- Review the registration fee and withdrawal model.
- Verify contracts on the supported block explorer when possible.

## License

MIT
