const hre = require("hardhat");

// Project creator/admin address.
// Verify this address before deploying.
const CREATOR_ADDRESS = "0x2768ef0331cfde4cab0ffbf989c8f9d622c64c10";

async function main() {
  const [deployer] = await hre.ethers.getSigners();

  console.log("Deploying with account:", deployer.address);
  console.log(
    "zkLTC balance:",
    hre.ethers.formatEther(
      await hre.ethers.provider.getBalance(deployer.address)
    )
  );

  // 1. Deploy ANSRegistry with a 0 zkLTC registration fee.
  const ANSRegistry = await hre.ethers.getContractFactory("ANSRegistry");
  const registry = await ANSRegistry.deploy(0);
  await registry.waitForDeployment();

  const registryAddress = await registry.getAddress();
  console.log("ANSRegistry deployed to:", registryAddress);

  // 2. Deploy AgentScorer and link it to ANSRegistry.
  const AgentScorer = await hre.ethers.getContractFactory("AgentScorer");
  const scorer = await AgentScorer.deploy(registryAddress);
  await scorer.waitForDeployment();

  const scorerAddress = await scorer.getAddress();
  console.log("AgentScorer deployed to:", scorerAddress);

  // 3. Authorize the project creator as an official scanner.
  const txScanner = await scorer.addScanner(CREATOR_ADDRESS);
  await txScanner.wait();
  console.log("Scanner authorized for:", CREATOR_ADDRESS);

  // 4. Remove the deployer from the scanner role.
  // The deployer is initially a scanner because the scorer constructor
  // automatically authorizes its deployer.
  if (deployer.address.toLowerCase() !== CREATOR_ADDRESS.toLowerCase()) {
    const txRemoveDeployer = await scorer.removeScanner(deployer.address);
    await txRemoveDeployer.wait();
    console.log("Deployer scanner role removed:", deployer.address);
  }

  // 5. Transfer admin control of both contracts to the project creator.
  const txAdminRegistry = await registry.setAdmin(CREATOR_ADDRESS);
  await txAdminRegistry.wait();
  console.log("ANSRegistry admin transferred to:", CREATOR_ADDRESS);

  const txAdminScorer = await scorer.setAdmin(CREATOR_ADDRESS);
  await txAdminScorer.wait();
  console.log("AgentScorer admin transferred to:", CREATOR_ADDRESS);

  console.log("\n=== Deployment Complete ===");
  console.log("ANSRegistry:", registryAddress);
  console.log("AgentScorer:", scorerAddress);
  console.log(
    "\nCopy these addresses into frontend/index.html under CONFIG.registryAddress and CONFIG.scorerAddress."
  );
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
